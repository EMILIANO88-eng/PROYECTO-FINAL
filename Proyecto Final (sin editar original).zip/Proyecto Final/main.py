from p5 import *
# Importa librerías del sistema para gestionar rutas de archivos y carpetas
import sys
import os

# Importar clases siguiendo tu estructura
sys.path.append(os.path.join(os.path.dirname(__file__), 'classes'))
from classes.sky import Sky
from classes.building import Building
from classes.cloud import Cloud

stars = []
buildings = []
clouds = []

def setup():
    size(800, 600)
    title("Roku City Inspired - POO")
    
    # Inicializar el cielo
    for _ in range(100):
        stars.append(Sky())
        
    # Inicializar nubes
    for _ in range(5):
        clouds.append(Cloud())
        
    # Inicializar edificios con separación
    for i in range(10):
        buildings.append(Building(i * 120))
           

def draw():
    # Fondo gradiente nocturno
    background(15, 0, 30) 
    
    # Dibujar y mover estrellas
    for s in stars:
        s.mover()
        s.dibujar()
        
    # Dibujar y mover nubes (Paralaje lento)
    for c in clouds:
        c.mover()
        c.dibujar()
        
    # Dibujar y mover edificios (Capa frontal)
    for b in buildings:
        b.mover()
        b.dibujar()

if __name__ == '__main__':
    run()