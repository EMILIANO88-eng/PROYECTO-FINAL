from p5 import *
import random

class Cloud:
    def __init__(self):
        # Define una posición horizontal aleatoria entre 0 y 800
        self.x = random.uniform(0, 800)
        # Define una posición vertical aleatoria entre 50 y 200 (parte superior)
        self.y = random.uniform(50, 200)
        # Velocidad constante de movimiento hacia la izquierda
        self.speed = 0.5
        # Tamaño aleatorio para la nube
        self.size = random.uniform(100, 200)

    def mover(self):
        # Resta la velocidad a 'x' para que la nube avance a la izquierda
        self.x -= self.speed
        # Si la nube sale completamente por el borde izquierdo...
        if self.x + self.size < 0:
            # Reaparece por el borde derecho (efecto de bucle)
            self.x = 800 + self.size

    def dibujar(self):
        # Desactiva los bordes de la figura
        no_stroke()
        # Define el color: púrpura (R=100, G=50, B=150) con transparencia (alfa=50)
        fill(100, 50, 150, 50) 
        # Dibuja una elipse en la posición actual; el ancho es 'size' y el alto es la mitad
        ellipse((self.x, self.y), self.size, self.size/2)