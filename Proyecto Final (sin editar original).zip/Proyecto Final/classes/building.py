from p5 import *
import random

class Building:
    def __init__(self, x_pos):
        # --- ATRIBUTOS DE DIMENSIÓN Y VELOCIDAD ---
        self.x = x_pos
        self.width = random.uniform(100, 160)
        self.height = random.uniform(350, 580)
        # Velocidad constante para mantener el ritmo del scroll
        self.speed = 1.2 
        
        # --- ATRIBUTOS ESTÉTICOS (Paleta de color intencionada) ---
        # Colores oscuros para la base, permitiendo que el neón resalte
        self.base_fill = random.choice([(20, 10, 40), (10, 5, 30), (30, 20, 50)])
        self.neon_color = random.choice([
            (180, 50, 255), # Púrpura neón
            (0, 255, 255),   # Cian neón
            (255, 0, 150)    # Rosa neón
        ])
        
        # --- LÓGICA INTERNA DE VENTANAS ---
        self.rows = int(self.height / 35)
        self.cols = 3
        # Matriz para decidir qué ventanas están encendidas (True) o apagadas (False)
        self.window_grid = [[random.random() > 0.6 for _ in range(self.cols)] for _ in range(self.rows)]

    def mover(self):
        # Desplazamiento horizontal
        self.x -= self.speed
        
        # Reset de posición al salir de la pantalla (Loop infinito)
        if self.x + self.width < 0:
            self.x = 800 + self.width
            # Variamos la altura al regenerarse para que la ciudad se sienta viva
            self.height = random.uniform(350, 580)

    def dibujar(self):
        # push_matrix() asegura que las traslaciones solo afecten a este objeto
        push_matrix()
        
        # Trasladamos el origen al punto inferior izquierdo del edificio
        translate(self.x, 600)
        
        # 1. CUERPO PRINCIPAL (Sombra y Profundidad)
        stroke(*self.neon_color)
        stroke_weight(3)
        fill(*self.base_fill)
        # Dibujamos hacia arriba (valor negativo en Y)
        rect((0, 0), self.width, -self.height)
        
        # 2. DETALLE DE "CAPA EXTERNA" (Estructura arquitectónica)
        # Una franja lateral más oscura para dar volumen
        no_stroke()
        fill(0, 0, 0, 100)
        rect((self.width * 0.7, 0), self.width * 0.3, -self.height)
        
        # 3. VENTANAS DINÁMICAS (Gestión autónoma de estética)
        w_w = self.width / (self.cols + 2) # Ancho proporcional de ventana
        w_h = 12 # Alto fijo de ventana
        
        for r in range(self.rows):
            for c in range(self.cols):
                if self.window_grid[r][c]:
                    # Luz de ventana con brillo (glow)
                    fill(*self.neon_color, 150) # Color neón con transparencia
                    # Posicionamiento calculado por columnas y filas
                    v_x = w_w + (c * (w_w * 1.5))
                    v_y = -40 - (r * 30)
                    rect((v_x, v_y), w_w, w_h)
                    
                    # Pequeño detalle de reflejo blanco dentro de la ventana
                    fill(255, 255, 255, 200)
                    rect((v_x + 2, v_y + 2), w_w/4, w_h/4)

        # 4. REMATE SUPERIOR (Antenas y detalles de techo)
        stroke(*self.neon_color)
        stroke_weight(2)
        # Antena principal
        line((self.width/2, -self.height), (self.width/2, -self.height - 50))
        # Luz de advertencia en la punta (parpadeo visual)
        no_stroke()
        fill(255, 0, 0)
        circle((self.width/2, -self.height - 55), 4)
        
        # 5. LÍNEAS DE DISEÑO (Estética Cyberpunk/Roku)
        stroke(*self.neon_color, 80)
        stroke_weight(1)
        for i in range(3):
            line((0, -self.height + (i*15)), (self.width, -self.height + (i*15)))

        pop_matrix() # Restauramos el estado para el siguiente objeto