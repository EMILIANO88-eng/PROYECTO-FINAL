from p5 import *
import random

class Sky:
    def __init__(self):
        # Posición aleatoria en toda la pantalla (800x400)
        self.x = random.uniform(0, 800)
        self.y = random.uniform(0, 400)
        # Tamaño pequeño (punto) entre 1 y 4 píxeles
        self.size = random.uniform(1, 4)
        # Nivel de brillo inicial aleatorio (de tenue a brillante)
        self.brightness = random.uniform(100, 255)
        # Velocidad a la que cambiará el brillo (efecto parpadeo)
        self.delta = random.uniform(1, 5)

    def mover(self):
        # Incrementa o decrementa el brillo según el valor de 'delta'
        self.brightness += self.delta
        # Si el brillo llega al máximo (255) o al mínimo (100)...
        if self.brightness > 255 or self.brightness < 100:
            # Invierte la dirección del cambio (si subía, ahora baja y viceversa)
            self.delta *= -1

    def dibujar(self):
        # Desactiva los bordes
        no_stroke()
        # Color blanco con la transparencia variable calculada en mover()
        fill(255, 255, 255, self.brightness)
        # Dibuja un círculo pequeño (la estrella)
        circle((self.x, self.y), self.size)